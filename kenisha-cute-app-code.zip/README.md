# Kenisha — Cute Private App
New kawaii pastel redesign with stickers, thought notes, photos, videos, music UI, favorites, themes, and settings.
Passcode: 1601
The original 59 photos and 18 videos are preserved in app/src/main/assets.
Build with: gradle assembleDebug
