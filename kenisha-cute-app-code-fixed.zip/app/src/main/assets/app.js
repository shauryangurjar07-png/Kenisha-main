const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const photoFiles=["1000038366.jpg", "1000038370.jpg", "1000038371.jpg", "1000038372.jpg", "1000038373.jpg", "1000039420.jpg", "1000039562.jpg", "1000039563.jpg", "1000039636.png", "1000039637.jpg", "1000039638.jpg", "1000039639.jpg", "1000039640.jpg", "1000039641.jpg", "1000039642.jpg", "1000039643.jpg", "1000039644.jpg", "1000039645.jpg", "1000039646.jpg", "1000039647.jpg", "1000039648.jpg", "1000039649.jpg", "1000039650.jpg", "1000039651.jpg", "1000039969.jpg", "1000039970.jpg", "1000039971.jpg", "1000039972.jpg", "1000040401.jpg", "1000040402.jpg", "1000040403.jpg", "1000040404.jpg", "1000040405.jpg", "1000040406.jpg", "1000040408.jpg", "1000040409.jpg", "1000040412.jpg", "1000040413.jpg", "1000040414.jpg", "1000040415.jpg", "1000040417.jpg", "1000040494.jpg", "1000040773.jpg", "1000040774.jpg", "1000040775.jpg", "1000040776.jpg", "1000040777.jpg", "1000040778.jpg", "1000040779.jpg", "1000040780.jpg", "1000040843.jpg", "1000040844.jpg", "1000040845.jpg", "1000040846.jpg", "1000040847.jpg", "1000040848.jpg", "1000040849.jpg", "1000040850.jpg", "1000040909.jpg"];
const videoFiles=["1000038364.mp4", "1000038365.mp4", "1000039566.mp4", "1000039568.mp4", "1000039569.mp4", "1000039570.mp4", "1000040035.mp4", "1000040400.mp4", "1000040416.mp4", "1000040784.mp4", "1000040785.mp4", "1000040792.mp4", "1000040800.mp4", "1000040801.mp4", "1000040802.mp4", "1000040803.mp4", "1000040804.mp4", "1000040805.mp4"];
let pin="", currentPage="home", favorites=new Set(JSON.parse(localStorage.getItem("kenishaFav")||"[]"));
const keypad=$("#keypad");
[1,2,3,4,5,6,7,8,9,"⌫",0].forEach(n=>{const b=document.createElement("button");b.textContent=n;b.onclick=()=>{if(n==="⌫")pin=pin.slice(0,-1);else if(pin.length<4)pin+=n;updateDots();if(pin.length===4){if(pin==="1601"){setTimeout(()=>{$("#lock").classList.add("hidden");$("#main").classList.remove("hidden")},180)}else{pin="";setTimeout(updateDots,250)}}};keypad.appendChild(b)});
function updateDots(){$$("#dots i").forEach((x,i)=>x.classList.toggle("filled",i<pin.length))}
function imgPath(f){return "assets/photos/"+f}
function renderPhotos(){const g=$("#photoGrid");g.innerHTML="";photoFiles.forEach((f,i)=>{const b=document.createElement("button");b.innerHTML=`<img src="${imgPath(f)}" alt="Memory ${i+1}">`;b.onclick=()=>openViewer(f,i);g.appendChild(b)})}
function renderRecent(){const g=$("#recent");photoFiles.slice(0,6).forEach((f,i)=>{const im=document.createElement("img");im.src=imgPath(f);im.onclick=()=>openViewer(f,i);g.appendChild(im)})}
function renderVideos(){const g=$("#videoGrid");g.innerHTML="";videoFiles.forEach((f,i)=>{const d=document.createElement("div");d.className="video-card-item";d.innerHTML=`<video src="assets/videos/${f}" muted preload="metadata" controls></video><b>Little moment ${i+1} ♡</b>`;g.appendChild(d)})}
function renderFav(){const g=$("#favGrid");g.innerHTML="";const arr=[...favorites];arr.forEach((idx)=>{const f=photoFiles[idx];if(!f)return;const b=document.createElement("button");b.innerHTML=`<img src="${imgPath(f)}">`;b.onclick=()=>openViewer(f,idx);g.appendChild(b)})}
function openViewer(f,i){$("#viewerImg").src=imgPath(f);$("#viewerCaption").textContent=`Memory ${i+1} of ${photoFiles.length} ♡`;$("#viewer").classList.remove("hidden")}
$("#viewer .close").onclick=()=>$("#viewer").classList.add("hidden");
function show(page){currentPage=page;$$(".page").forEach(p=>p.classList.toggle("active",p.id===page));if(page==="photos")renderPhotos();if(page==="videos")renderVideos();if(page==="favorites")renderFav();$$(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page))}
$$("[data-page]").forEach(b=>b.onclick=()=>show(b.dataset.page));
$$(".back").forEach(b=>b.onclick=()=>show("home"));
$$("[data-action='settings']").forEach(b=>b.onclick=()=>show("settings"));
$$("[data-action='theme']").forEach(b=>b.onclick=()=>show("themes"));
$$("[data-theme]").forEach(b=>b.onclick=()=>{document.body.dataset.theme=b.dataset.theme;localStorage.setItem("kenishaTheme",b.dataset.theme)});
$$(".song").forEach(s=>s.onclick=()=>{$("#trackName").textContent=s.dataset.song});
$("#play").onclick=()=>{$("#play").textContent=$("#play").textContent==="▶"?"Ⅱ":"▶"});
document.body.dataset.theme=localStorage.getItem("kenishaTheme")||"pink";
$("#photoCount").textContent=`${photoFiles.length} beautiful memories`;
$("#videoCount").textContent=`${videoFiles.length} little moments`;
renderRecent();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
